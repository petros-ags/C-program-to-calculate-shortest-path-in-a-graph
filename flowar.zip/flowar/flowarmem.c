#include <stdio.h>
#include <stdlib.h>
#include "flowar.h"

int P(int i, int j, int k, int **graph, int ***mem)					// P function is called by "solve" function to calculate shortest path.mem is an array to store calculated shortest paths so i dont need to calculate them again.
{
	int x = -3, y = -3, z = -3;							//x,y,z initialisation.These values represent graph[i][j] , graph[i][k] , graph[k][j] respectively
	if (k > 0)
	{										// Three cases:k > 0 , k = 0 , k < 0.Instead of two cases used in flowarrec file(k >= 0 , k < 0).I did that because otherwise,the values stored inside mem after they were calculated,in case k was equal to 0,overflowed the mem array
		if (mem[i][j][k-1] != -2)
		{
			x = mem[i][j][k-1];
		}
		if (mem[i][k][k-1] != -2)
		{
			y = mem[i][k][k-1];
		}
		if (mem[k][j][k-1] != -2)
		{
			z = mem[k][j][k-1];
		}
		if(x == -3)
		{
			x = P(i, j, k-1, graph, mem);
			mem[i][j][k-1] = x;
		}
		if(y == -3)
		{
			y = P(i, k, k-1, graph, mem);
			mem[i][k][k-1] = y;
		}
		if(z == -3)
		{
			z = P(k, j, k-1, graph, mem);
			mem[k][j][k-1] = z;
		}	
		if (x == -1)	
		{
			if (y == -1 || z == -1)
			{
				return -1;
			}
			return y+z;
		}
		if (y == -1 || z == -1) 
		{
			return x;
		}
		return (x < y+z ? x : y+z);						// an unusual way of comparing values,dont you think?
	}
	else if (k == 0)
	{
		x = graph[i][j];
		y = graph[i][k];
		z = graph[k][j];
		if (x == -1)	
		{
			if (y == -1 || z == -1)
			{
				return -1;
			}
			return y+z;
		}
		if (y == -1 || z == -1) 
		{
			return x;
		}
		return (x < y+z ? x : y+z);
	}
	else
	{
		return graph[i][j];
	}
}

void solve(int n, int **graph)								//solve function
{
	int i, j, k;
	int ***mem = malloc(sizeof(int**)*n);
	if (mem == NULL)								//here i create mem and initialize it with value -2 to represent an infinite value(not -1 because it is used to define infinite for the recursive type.
	{
		printf("Failed to allocate memory for cached graph\n");
		return;
	}
	for (i = 0; i < n; i++)
	{
		mem[i] = malloc(sizeof(int*)*n);
		if (mem[i] == NULL)
		{
			printf("Failed to allocate memory for cached graph\n");
			return;
		}
		for (j = 0; j < n; j++)
		{
			mem[i][j] = malloc(sizeof(int)*n);
			if (mem[i][j] == NULL)
			{
				printf("Failed to allocate memory for cached graph\n");
				return;
			}
			for (k = 0; k < n; k++)
			{
				mem[i][j][k] = -2;					 // mem[i][j][k] == -2 as a starting value so the program knows it needs to calculate that
			}
		}
	}
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < i; j++)
		{
			printf("From node %d to node %d: Length of shortest path is %d\n", i, j, P(i,j,n-1, graph, mem)); 	//still here?Ok you got me,i print those goddamn results you asked for
		}
		printf("\n");
	}
		
	for (i = 0; i < n; i++)								// here,memory allocated for mem array is freed
	{
		for (j = 0; j < n; j++)
		{
			free(mem[i][j]);
		}
		free(mem[i]);
	}
	free(mem);
	return;
}
