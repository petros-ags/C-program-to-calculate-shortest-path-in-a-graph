#include <stdio.h>
#include <stdlib.h>
#include "flowar.h"

int main(void)
{
	int n, i, j;
	scanf("%d", &n);
	int **graph = malloc(sizeof(int*)*n);						//creating graph
	if (graph == NULL)
		{
			printf("Failed to allocate memory for graph\n");
			return 1;
		}
	for (i = 0; i < n; i++)
	{
		graph[i] = malloc(sizeof(int)*n);
		if (graph[i] == NULL)
		{
			printf("Failed to allocate memory for graph\n");
			return 1;
		}
	}
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < i; j++)
		{
			scanf("%d", &graph[i][j]);
			graph[j][i] = graph[i][j];
		}
		graph[i][i] = 0;
	}
	solve(n, graph);
	for (i = 0; i < n; i++)								//free memory of graph
	{
		free(graph[i]);
	}
	free(graph);
	return 0;
}
