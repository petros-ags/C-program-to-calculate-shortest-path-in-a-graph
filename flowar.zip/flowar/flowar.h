
void solve(int, int**);



