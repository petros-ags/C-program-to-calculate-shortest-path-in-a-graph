#include <stdio.h>
#include <stdlib.h>
#include "flowar.h"

int P(int i, int j, int k, int **graph)					// P function is called by "solve" function to calculate shortest path
{
	int x, y, z;
	if (k >= 0)
	{
		x = P(i, j, k-1, graph);
		y = P(i, k, k-1, graph);
		z = P(k, j, k-1, graph);
		if (x == -1)
		{
			if (y == -1 || z == -1) return -1;
			return y+z;
		}
		if (y == -1 || z == -1) return x;
		return (x < y+z ? x : y+z	);
	}
	else return graph[i][j];
}

void solve(int n, int **graph)						// solve function
{
	int i, j;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < i; j++)
			printf("From node %d to node %d: Length of shortest path is %d\n", i, j, P(i,j,n-1, graph));	//what you looking at?just printing the results
		printf("\n");
	}
}

