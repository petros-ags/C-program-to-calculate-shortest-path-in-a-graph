#include <stdio.h>
#include <stdlib.h>
#include "flowar.h"

#ifndef PATH											//if i dont compile with -DPATH this block of code is what the program will use
void solve(int n, int **graph)
{
	int i, j, k;
	int **Q = malloc(sizeof(int*)*n);
	if (Q == NULL)										// Q array is created here
	{
		printf("Failed to allocate memory for Q array\n");
		return;
	}
	for (i = 0; i < n; i++)
	{
		Q[i] = malloc(sizeof(int*)*n);
		if (Q[i] == NULL)
		{
			printf("Failed to allocate memory for Q array\n");
			return;
		}
		for (j = 0; j < n; j++)
		{
			Q[i][j] = graph[i][j];							//Q initialised with graph values
		}
	}
	for(k=0;k<n;k++)									//finding shortest paths(cost-wise)
  		for(i=0;i<n;i++)
   			for(j=0;j<n;j++)
				{
					if (Q[i][j] == -1)
					{
						if (Q[i][k] == -1 || Q[k][j] == -1)
						{
							continue;
						}
						else
						{
							Q[i][j] = Q[i][k] + Q[k][j];
						}
					}
					else
					{
						if (Q[i][k] == -1 || Q[k][j] == -1)
						{
							continue;
						}
						Q[i][j] = (Q[i][j] > Q[i][k] + Q[k][j] ? Q[i][k] + Q[k][j] : Q[i][j]);
					}
				}
   				
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < i; j++)
		{
			printf("From node %d to node %d: Length of shortest path is %d\n", i, j, Q[i][j]);	//you know...
		}
		printf("\n");
	}
	for (i = 0; i < n; i++)											//free memory of Q
	{
		free(Q[i]);
	}
	free(Q);
	return;
}
#endif

#ifdef PATH											//you know me by now...no?Well...let me explain:compile with -DPATH
void solve(int n, int **graph)
{
	int i, j, k, m;
	int **Q = malloc(sizeof(int*)*n);
	if (Q == NULL)										// Q array is created here
	{
		printf("Failed to allocate memory for Q array\n");
		return;
	}
	for (i = 0; i < n; i++)
	{
		Q[i] = malloc(sizeof(int*)*n);
		if (Q[i] == NULL)
		{
			printf("Failed to allocate memory for Q array\n");
			return;
		}
		for (j = 0; j < n; j++)
		{	
			Q[i][j] = graph[i][j];							//Q initialised with graph values
		}	
	}
	int **next = malloc(sizeof(int*)*n);
	if (next == NULL)
	{
		printf("Failed to allocate memory for next array\n");
		return;
	}
	for (i = 0; i < n; i++)									//next array to use to find shortest paths(not the cost,the actual path)
	{
		next[i] = malloc(sizeof(int*)*n);
		if (next[i] == NULL)
		{
			printf("Failed to allocate memory for next array\n");
			return;
		}
		for (j = 0; j < n; j++)
		{
			next[i][j] = j;
		}
	}
	for(k=0;k<n;k++)									//the main calculate process
  		for(i=0;i<n;i++)
   			for(j=0;j<n;j++)
				{
					if (Q[i][j] == -1)
					{
						if (Q[i][k] == -1 || Q[k][j] == -1)
						{
							continue;
						}
						else
						{
							Q[i][j] = Q[i][k] + Q[k][j];
							next[i][j] = k;				//this for paths
						}
					}
					else
					{
						if (Q[i][k] == -1 || Q[k][j] == -1)
						{
							continue;
						}
						if (Q[i][j] > Q[i][k] + Q[k][j])
						{
							Q[i][j] = Q[i][k] + Q[k][j];
							next[i][j] = k;				//you guessed it,yeah,its also for paths
						}
					}
				}								//until here
   				
	for (i = 0; i < n; i++)									//path printing process
	{
		m = i;
		for (j = 0; j < i; j++)
		{
			printf("From node %d to node %d: Length of shortest path is %d\n", i, j, Q[i][j]); 	//oops thats not for the paths,but for the costs
			printf("Shortest path is: %d", i);	
			while (m != j)
			{
				printf(" -> %d", next[m][j]);
				m = next[m][j];
			}
			printf("\n");
		}
		printf("\n");
	}
	for (i = 0; i < n; i++)											//free memory of next
	{
		free(next[i]);
	}
	free(next);
	for (i = 0; i < n; i++)											//free memory of Q
	{
		free(Q[i]);
	}
	free(Q);
	return;
}
#endif
